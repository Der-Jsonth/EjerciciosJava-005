package cl.ejercicio.biblioteca.controller;

import cl.ejercicio.biblioteca.model.Libro;
import cl.ejercicio.biblioteca.model.Material;
import cl.ejercicio.biblioteca.model.Reservable;
import cl.ejercicio.biblioteca.model.Revista;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Controlador: eventos JavaFX, lista observable y persistencia directa con Gson. */
public class BibliotecaController {
    private final ObservableList<Material> materiales = FXCollections.observableArrayList();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final Path archivo = Path.of("materiales.json");

    @FXML private TableView<Material> tablaMateriales;
    @FXML private TableColumn<Material, String> colCodigo;
    @FXML private TableColumn<Material, String> colTitulo;
    @FXML private TableColumn<Material, String> colAnio;
    @FXML private TableColumn<Material, String> colTipo;
    @FXML private TableColumn<Material, String> colDetalle;
    @FXML private TableColumn<Material, String> colEstado;
    @FXML private TextField txtCodigo;
    @FXML private TextField txtTitulo;
    @FXML private TextField txtAnio;
    @FXML private TextField txtDetalle;
    @FXML private ComboBox<String> cmbTipo;
    @FXML private Label lblEstado;

    @FXML
    private void initialize() {
        cmbTipo.getItems().addAll("Libro", "Revista");
        cmbTipo.getSelectionModel().selectFirst();

        colCodigo.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getCodigo()));
        colTitulo.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getTitulo()));
        colAnio.setCellValueFactory(d -> new ReadOnlyStringWrapper(String.valueOf(d.getValue().getAnio())));
        colTipo.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getTipo()));
        colDetalle.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getDetalle()));
        colEstado.setCellValueFactory(d -> new ReadOnlyStringWrapper(d.getValue().getEstado()));

        tablaMateriales.setItems(materiales);
    }

    @FXML
    private void agregarMaterial() {
        try {
            String codigo = txtCodigo.getText().trim();
            String titulo = txtTitulo.getText().trim();
            int anio = Integer.parseInt(txtAnio.getText().trim());
            String detalle = txtDetalle.getText().trim();

            Material nuevo;
            if ("Libro".equals(cmbTipo.getValue())) {
                nuevo = new Libro(codigo, titulo, anio, detalle, false);
            } else if ("Revista".equals(cmbTipo.getValue())) {
                nuevo = new Revista(codigo, titulo, anio, Integer.parseInt(detalle));
            } else {
                throw new IllegalArgumentException("Debes seleccionar Libro o Revista.");
            }

            if (materiales.stream().anyMatch(m -> m.getCodigo().equalsIgnoreCase(nuevo.getCodigo()))) {
                throw new IllegalArgumentException("Ya existe un material con ese código.");
            }
            materiales.add(nuevo);
            tablaMateriales.getSelectionModel().select(nuevo);
            txtCodigo.clear();
            txtTitulo.clear();
            txtAnio.clear();
            txtDetalle.clear();
            lblEstado.setText("Agregado: " + nuevo.getTitulo() + ". Pulsa Guardar JSON para conservarlo.");
        } catch (NumberFormatException e) {
            lblEstado.setText("El año y el número de edición deben ser enteros válidos.");
        } catch (IllegalArgumentException e) {
            lblEstado.setText("No se pudo agregar: " + e.getMessage());
        }
    }

    @FXML
    private void cargarJson() {
        if (Files.notExists(archivo)) {
            lblEstado.setText("No existe el archivo: " + archivo.toAbsolutePath());
            return;
        }

        // Construir la lista completa ANTES de reemplazar la tabla. Así no se pierden
        // los registros visibles si el archivo contiene errores.
        try (Reader reader = Files.newBufferedReader(archivo, StandardCharsets.UTF_8)) {
            JsonElement raiz = JsonParser.parseReader(reader);
            if (!raiz.isJsonArray()) {
                throw new IllegalArgumentException("El JSON debe contener una lista de materiales.");
            }

            List<Material> cargados = new ArrayList<>();
            Set<String> codigos = new HashSet<>();
            for (JsonElement elemento : raiz.getAsJsonArray()) {
                JsonObject obj = elemento.getAsJsonObject();
                String tipo = obj.get("tipo").getAsString();
                Material material;
                if ("Libro".equals(tipo)) {
                    Libro libro = gson.fromJson(obj, Libro.class);
                    material = new Libro(libro.getCodigo(), libro.getTitulo(), libro.getAnio(),
                                         libro.getAutor(), libro.isReservado());
                } else if ("Revista".equals(tipo)) {
                    Revista revista = gson.fromJson(obj, Revista.class);
                    material = new Revista(revista.getCodigo(), revista.getTitulo(), revista.getAnio(),
                                           revista.getNumeroEdicion());
                } else {
                    throw new IllegalArgumentException("Tipo desconocido: " + tipo);
                }
                if (!codigos.add(material.getCodigo().toLowerCase(Locale.ROOT))) {
                    throw new IllegalArgumentException("Código duplicado en JSON: " + material.getCodigo());
                }
                cargados.add(material);
            }
            materiales.setAll(cargados);
            lblEstado.setText("Cargados " + materiales.size() + " materiales desde materiales.json.");
        } catch (IOException | RuntimeException e) {
            lblEstado.setText("Error al cargar JSON: " + e.getMessage());
        }
    }

    @FXML
    private void guardarJson() {
        try {
            JsonArray arreglo = new JsonArray();
            for (Material material : materiales) {
                JsonObject obj = gson.toJsonTree(material).getAsJsonObject();
                // El tipo permite reconstruir la subclase (Libro o Revista) al leer.
                obj.addProperty("tipo", material.getTipo());
                arreglo.add(obj);
            }
            try (Writer writer = Files.newBufferedWriter(archivo, StandardCharsets.UTF_8)) {
                gson.toJson(arreglo, writer);
            }
            lblEstado.setText("Guardados " + materiales.size() + " materiales en materiales.json.");
        } catch (IOException e) {
            lblEstado.setText("Error al guardar JSON: " + e.getMessage());
        }
    }

    @FXML
    private void reservarSeleccionado() {
        Material material = tablaMateriales.getSelectionModel().getSelectedItem();
        if (material == null) {
            lblEstado.setText("Selecciona un material en la tabla.");
        } else if (material instanceof Reservable reservable) {
            if (reservable.isReservado()) {
                lblEstado.setText("Este libro ya estaba reservado.");
            } else {
                reservable.reservar();
                tablaMateriales.refresh();
                lblEstado.setText("Libro reservado. Guarda JSON para conservar el cambio.");
            }
        } else {
            lblEstado.setText("Las revistas no admiten reservas.");
        }
    }

    @FXML
    private void liberarSeleccionado() {
        Material material = tablaMateriales.getSelectionModel().getSelectedItem();
        if (material == null) {
            lblEstado.setText("Selecciona un material en la tabla.");
        } else if (material instanceof Reservable reservable) {
            if (!reservable.isReservado()) {
                lblEstado.setText("Este libro ya estaba disponible.");
            } else {
                reservable.liberarReserva();
                tablaMateriales.refresh();
                lblEstado.setText("Reserva liberada. Guarda JSON para conservar el cambio.");
            }
        } else {
            lblEstado.setText("Las revistas no admiten reservas.");
        }
    }
}
