# Biblioteca LibroVivo — JavaFX + Gson (versión simplificada)

Ejercicio centrado en **FXML, controlador, TableView, ObservableList y JSON con Gson**.
NO usa las capas DAO ni Repository. Solo hay tres clases del modelo (`Material`, `Libro`,
`Revista`) y la interfaz `Reservable`. Las tres clases y la interfaz ya están implementadas.

## Estructura del proyecto

```
BibliotecaJavaFX/
├── pom.xml
├── materiales.json
├── DIAGRAMA_CLASES.png / .puml / .dot
└── src/main/
    ├── java/
    │   ├── module-info.java
    │   └── cl/ejercicio/biblioteca/
    │       ├── BibliotecaApp.java
    │       ├── model/ (Material, Libro, Revista, Reservable)
    │       └── controller/BibliotecaController.java
    └── resources/cl/ejercicio/biblioteca/
        ├── biblioteca-view.fxml
        └── estilos.css
```

## Ejecución

Usar JDK 17+, IntelliJ IDEA con Maven y Scene Builder.
Abrir `BibliotecaJavaFX` como proyecto Maven y ejecutar `BibliotecaApp` o desde la raíz:

- Windows: `mvnw.cmd clean javafx:run`
- Linux/macOS: `./mvnw clean javafx:run`

`materiales.json` se lee y escribe en el directorio de ejecución. Asegura el **Working directory**
en la raíz del proyecto. Al pulsar **Cargar JSON** deben aparecer 4 filas en la tabla (solo en
la solución; en la práctica debes completar los TODO primero).

## Flujo

```
FXML <--> BibliotecaController <--> ObservableList<Material> <--> TableView
                   |
                   +---- Gson + Files <--> materiales.json
```

Gson necesita saber qué subclase reconstruir porque `Material` es abstracta: cada registro
JSON incorpora el campo `tipo` con `Libro` o `Revista`. El controlador convierte ese campo
en una instancia concreta y valida los datos antes de actualizar la lista visible.

## Pruebas

1. Cargar JSON: 4 filas (2 libros, 2 revistas).
2. Agregar Libro L-003, `Java para todos`, 2020, `Ana Pérez`.
3. Reservar L-003 y comprobar columna Estado.
4. Intentar reservar una revista: debe advertir que no está permitido.
5. Intentar agregar código duplicado: se rechaza.
6. Guardar, cerrar, reabrir y cargar: persisten los cambios.
