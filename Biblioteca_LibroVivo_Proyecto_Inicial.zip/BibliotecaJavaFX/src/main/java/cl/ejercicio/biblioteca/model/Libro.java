package cl.ejercicio.biblioteca.model;

/** Hereda de Material e implementa el contrato Reservable. */
public class Libro extends Material implements Reservable {
    private String autor;
    private boolean reservado;

    public Libro() { super(); }

    public Libro(String codigo, String titulo, int anio, String autor, boolean reservado) {
        super(codigo, titulo, anio);
        setAutor(autor);
        this.reservado = reservado;
    }

    public String getAutor() { return autor; }
    public void setAutor(String autor) {
        if (autor == null || autor.isBlank()) {
            throw new IllegalArgumentException("El autor es obligatorio.");
        }
        this.autor = autor.trim();
    }

    @Override
    public boolean isReservado() { return reservado; }

    @Override
    public void reservar() { reservado = true; }

    @Override
    public void liberarReserva() { reservado = false; }

    @Override
    public String getTipo() { return "Libro"; }

    @Override
    public String getDetalle() { return autor; }

    @Override
    public String getEstado() { return reservado ? "Reservado" : "Disponible"; }
}
