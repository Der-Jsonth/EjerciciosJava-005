package cl.ejercicio.biblioteca.model;

/** Contrato para materiales que admiten reservas. */
public interface Reservable {
    boolean isReservado();
    void reservar();
    void liberarReserva();
}
