package cl.ejercicio.biblioteca.controller;

import cl.ejercicio.biblioteca.model.Libro;
import cl.ejercicio.biblioteca.model.Material;
import cl.ejercicio.biblioteca.model.Reservable;
import cl.ejercicio.biblioteca.model.Revista;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** PRÁCTICA: completar los TODO de JavaFX y Gson, sin DAO ni Repository. */
public class BibliotecaController {
    // Estas variables reemplazan por completo a la capa Repository y DAO.
    private final ObservableList<Material> materiales = FXCollections.observableArrayList();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final Path archivo = Path.of("materiales.json");

    @FXML private TableView<Material> tablaMateriales;
    @FXML private TableColumn<Material, String> colCodigo;
    @FXML private TableColumn<Material, String> colTitulo;
    @FXML private TableColumn<Material, String> colAnio;
    @FXML private TableColumn<Material, String> colTipo;
    @FXML private TableColumn<Material, String> colDetalle;
    @FXML private TableColumn<Material, String> colEstado;
    @FXML private TextField txtCodigo;
    @FXML private TextField txtTitulo;
    @FXML private TextField txtAnio;
    @FXML private TextField txtDetalle;
    @FXML private ComboBox<String> cmbTipo;
    @FXML private Label lblEstado;

    @FXML
    private void initialize() {
        // TODO A1: agregar Libro y Revista al ComboBox.
        // TODO A2: configurar las 6 columnas con setCellValueFactory y ReadOnlyStringWrapper.
        // TODO A3: enlazar tablaMateriales con materiales usando setItems(...).
    }

    @FXML
    private void cargarJson() {
        // TODO B1: comprobar que archivo exista y leerlo con Files.newBufferedReader(...).
        // TODO B2: usar JsonParser y Gson para recuperar Libro o Revista según el campo tipo.
        // TODO B3: validar registros y códigos duplicados; usar materiales.setAll(...) solo al final.
        // TODO B4: actualizar lblEstado y capturar errores de lectura/formato.
        lblEstado.setText("Pendiente: cargar JSON.");
    }

    @FXML
    private void guardarJson() {
        // TODO C1: convertir cada Material en JsonObject con gson.toJsonTree(...).
        // TODO C2: agregar el campo tipo y escribir el arreglo con Files.newBufferedWriter(...).
        // TODO C3: notificar éxito o error mediante lblEstado.
        lblEstado.setText("Pendiente: guardar JSON.");
    }

    @FXML
    private void agregarMaterial() {
        // TODO D1: leer datos del formulario y convertir año/edición a números.
        // TODO D2: crear Libro o Revista; impedir códigos repetidos (ignorar mayúsculas).
        // TODO D3: materiales.add(nuevo); limpiar campos; mostrar mensajes y errores.
        lblEstado.setText("Pendiente: agregar material.");
    }

    @FXML
    private void reservarSeleccionado() {
        // TODO E1: obtener getSelectionModel().getSelectedItem().
        // TODO E2: usar instanceof Reservable, reservar(), refresh() y lblEstado.
        lblEstado.setText("Pendiente: reservar selección.");
    }

    @FXML
    private void liberarSeleccionado() {
        // TODO E3: usar instanceof Reservable, liberarReserva(), refresh() y lblEstado.
        lblEstado.setText("Pendiente: liberar reserva.");
    }
}
