package cl.ejercicio.biblioteca;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class BibliotecaApp extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(
            BibliotecaApp.class.getResource("biblioteca-view.fxml"));
        Parent root = loader.load();
        stage.setTitle("Biblioteca - JavaFX y Gson");
        stage.setScene(new Scene(root, 1000, 680));
        stage.setMinWidth(840);
        stage.setMinHeight(590);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
