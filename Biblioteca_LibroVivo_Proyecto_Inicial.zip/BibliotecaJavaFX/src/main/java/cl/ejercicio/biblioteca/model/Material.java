package cl.ejercicio.biblioteca.model;

/** Clase base abstracta de los materiales de la biblioteca. */
public abstract class Material {
    private String codigo;
    private String titulo;
    private int anio;

    protected Material() {
        // Constructor vacío para herramientas de serialización.
    }

    protected Material(String codigo, String titulo, int anio) {
        setCodigo(codigo);
        setTitulo(titulo);
        setAnio(anio);
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) {
        if (codigo == null || codigo.isBlank()) {
            throw new IllegalArgumentException("El código es obligatorio.");
        }
        this.codigo = codigo.trim();
    }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) {
        if (titulo == null || titulo.isBlank()) {
            throw new IllegalArgumentException("El título es obligatorio.");
        }
        this.titulo = titulo.trim();
    }

    public int getAnio() { return anio; }
    public void setAnio(int anio) {
        if (anio < 1450 || anio > 2026) {
            throw new IllegalArgumentException("El año debe estar entre 1450 y 2026.");
        }
        this.anio = anio;
    }

    public abstract String getTipo();
    public abstract String getDetalle();
    public abstract String getEstado();

    @Override
    public String toString() {
        return titulo + " (" + anio + ")";
    }
}
