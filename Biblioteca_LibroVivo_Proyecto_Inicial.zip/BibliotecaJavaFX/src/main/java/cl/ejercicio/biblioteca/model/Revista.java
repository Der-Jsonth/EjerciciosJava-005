package cl.ejercicio.biblioteca.model;

/** Segundo tipo de Material: una revista de consulta en sala. */
public class Revista extends Material {
    private int numeroEdicion;

    public Revista() { super(); }

    public Revista(String codigo, String titulo, int anio, int numeroEdicion) {
        super(codigo, titulo, anio);
        setNumeroEdicion(numeroEdicion);
    }

    public int getNumeroEdicion() { return numeroEdicion; }
    public void setNumeroEdicion(int numeroEdicion) {
        if (numeroEdicion <= 0) {
            throw new IllegalArgumentException("La edición debe ser mayor que cero.");
        }
        this.numeroEdicion = numeroEdicion;
    }

    @Override
    public String getTipo() { return "Revista"; }

    @Override
    public String getDetalle() { return "Edición " + numeroEdicion; }

    @Override
    public String getEstado() { return "Solo consulta"; }
}
