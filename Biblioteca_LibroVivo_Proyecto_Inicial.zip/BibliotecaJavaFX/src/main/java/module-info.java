module cl.ejercicio.biblioteca {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;

    opens cl.ejercicio.biblioteca.controller to javafx.fxml;
    opens cl.ejercicio.biblioteca.model to com.google.gson;
    exports cl.ejercicio.biblioteca;
}
